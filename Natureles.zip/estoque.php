	<?php	 
	include 'connect.php';

  $login_cookie = $_COOKIE['login'];
    if(isset($login_cookie)){
    
    }else{
     
    echo "<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.html';</script>";
    }
	 
?>
<html>
	<head> 
	<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="new 1.css">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  	
	<div id='cssmenu'>
		<ul>
			<li ><a href="index.html"><span>Home</span></a></li>
			<li><a href="cadastrar.html"><span>Cadastrar Produtos</span></a></li>
			<li class='active'><a href="estoque.php"><span>Estoque</span></a></li>
			<li class='last'><a href="compras.html"><span>Produtos Comprados</span></a></li>
		</ul>
	</div>   
	<div class="Titulo">
		<div class="T-img">
			<A href="index.html"><img src="Naturales-logo.jpg" /> </a>
		</div>
	</div>
	</head>
		<body >
<div class="texto">
		<fieldset>
		<h3>Compras cadastradas</h3>
<?php
// Criando tabela e cabeçalho de dados:
 echo "<table border=1 align='center' style='color:#fff;'>";
 echo "<tr>";
 echo  "<th >Produto</th>";
 echo "<th >Quantidade</th>";
 echo "<th >Preço de compra</th>";
 echo "</tr>";
  $Color = "white";
 $sql = "SELECT produto,quantidade,preco_compra FROM compra_p";
 $resultado = mysqli_query($strcon,$sql) or die("Erro ao retornar dados");
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
    $prod = $registro['produto'];
    $qtd = $registro['quantidade'];
    $pre_comp = $registro['preco_compra'];
    echo "<tr align='center'>";
    echo "<td >".$prod."</td>";
    echo "<td >".$qtd."</td>";
    echo "<td >".$pre_comp."</td>";
    echo "</tr>";
 }
 mysqli_close($strcon);
 echo "</table>";
 ?>
 </fildeset>
 </div>
 </body>
 </html>