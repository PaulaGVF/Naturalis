<?php
include 'connect.php';
 $login_cookie = $_COOKIE['login'];
    if(isset($login_cookie)==false){
     
      echo "<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.html';</script>";
     
    }?>
<html>
	<head> 
	<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="new 1.css">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  	
	<div id='cssmenu'>
		<ul>
			<li class='active'><a href="index.html"><span>Home</span></a></li>
			<li><a href="cadastrar.html"><span>Cadastrar Produtos</span></a></li>
			<li><a href="estoque.php"><span>Estoque</span></a></li>
			<li class='last'><a href="compras.html"><span>Produtos Comprados</span></a></li>
		</ul>
	</div>   
	<div class="Titulo">
		<div class="T-img">
			<A href="index.html"><img src="Naturales-logo.jpg" /> </a>
		</div>
	</div>
	</head>
		<body >
<div class="texto">
		<fieldset>
		<h3>Preço médio</h3>
<?php
	$strcon= mysqli_connect("localhost", "id7030049_admin", "1234567","id7030049_natureles")or die("Erro");
 $nome=0;
	$nome = $_POST['nome'];
 
        echo "<table border=1 align='center' style='color:#fff;'>";
 echo "<tr>";
 echo  "<th >Produto</th>";
 echo "<th >Quantidade</th>";
 echo "<th >Preço de compra</th>";
 echo "<th >Preço de médio</th>";
 echo "</tr>";
  $sq=0;
  $sqp=0;
    $preco_medio= mysqli_query($strcon,"SELECT * FROM compra_p where produto = '$nome' ") or die("Error ao retornar dados");
     while ($registro = mysqli_fetch_array($preco_medio))
 {
    $prod = $registro['produto'];
    $qtd = $registro['quantidade'];
    $pre_comp = $registro['preco_compra'];
   $sq = $sq+ $qtd;
   $GLOBALS["sq"];
    $sqp += $qtd*$pre_comp;
    $GLOBALS["sqp"];
    
}
$pm=0;
$pm=  $sqp/ $sq;
$pm=number_format($pm, 2, '.', ' ');
    
 $resultado = mysqli_query($strcon,"SELECT * FROM compra_p where produto = '$nome'") or die("Erro ao retornar dados");
 // Obtendo os dados por meio de um loop while
      while ($registro = mysqli_fetch_array($resultado))
 { 
      $prod = $registro['produto'];
    $qtd = $registro['quantidade'];
    $pre_comp = $registro['preco_compra'];
    echo "<tr align='center'>";
    echo "<td >".$prod."</td>";
    echo "<td >". $sq."</td>";
    echo "<td >".$pre_comp."</td>";
    echo "<td >".$pm."</td>";
    echo "</tr>";
    
}

if (mysqli_query($strcon,"UPDATE compra_p SET preco_medio='$pm'  where produto = '$nome'") === TRUE) {
    echo "Preço médio cadastrado no banco de dados";
} else {
    echo "Erro ao cadastrar preço médio: " . $strcon->error;
}

 mysqli_close($strcon);
 echo "</table>";
        

 ?>
 <form>
<input type="button" value="Voltar" onClick="JavaScript: window.location.href='index.html';">
</form>
 </fildeset>
 </div>
 </body>
 </html>