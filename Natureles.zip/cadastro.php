 <?php
    include 'connect.php';
    
  $login_cookie = $_COOKIE['login'];
    if(isset($login_cookie)){
     
    }else{
     echo "<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.html';</script>";
    }
	 



	$nome = $_POST['nome'];
	mysqli_query($strcon, "INSERT INTO cadastro_p (nome) VALUES ('$nome')");
		echo "<script language='javascript' type='text/javascript'>alert('Produto cadastrado'); window.location.href='cadastrar.html' </script>";
	mysqli_close($strcon);
?>