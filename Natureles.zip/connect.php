<?php
$strcon= mysqli_connect("localhost", "id7030049_admin", "1234567","id7030049_natureles")or die("Erro");
?>