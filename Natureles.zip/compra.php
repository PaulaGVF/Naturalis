 <?php
	include 'connect.php';
    
  $login_cookie = $_COOKIE['login'];
    if(isset($login_cookie)){
     
    }else{
     
      echo "<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.html';</script>";
    }
	 


      $prod = $_POST['produto'];
	$qtd = $_POST['quantidade'];
	$p = $_POST['preco_compra'];
	mysqli_query($strcon, "INSERT INTO compra_p (produto,quantidade,preco_compra) VALUES ('$prod','$qtd','$p')");
		echo "<script language='Compra cadastrada';
'javascript' type='text/javascript'>alert('Compra cadastrada'); window.location.href='compras.html'</script>";
	mysqli_close($strcon);
?>